<?php
require_once(__DIR__."/../includes/db.php");
require_once(__DIR__."/../includes/admin_auth.php");
include(__DIR__."/../includes/header.php");
$users=$conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
$services=$conn->query("SELECT COUNT(*) c FROM services")->fetch_assoc()['c'];
$orders=$conn->query("SELECT COUNT(*) c FROM orders")->fetch_assoc()['c'];
?>
<h2 class="mb-4">Admin Dashboard</h2>
<div class="row g-3">
  <div class="col-md-4"><div class="card p-3"><h5>Users</h5><div class="display-6"><?= $users ?></div></div></div>
  <div class="col-md-4"><div class="card p-3"><h5>Services</h5><div class="display-6"><?= $services ?></div></div></div>
  <div class="col-md-4"><div class="card p-3"><h5>Orders</h5><div class="display-6"><?= $orders ?></div></div></div>
</div>
<div class="d-flex gap-2 mt-4">
  <a href="/admin/users.php" class="btn btn-outline-light">Manage Users</a>
  <a href="/admin/services.php" class="btn btn-outline-light">Manage Services</a>
  <a href="/admin/orders.php" class="btn btn-outline-light">View Orders</a>
  <a href="/admin/logout.php" class="btn btn-outline-light ms-auto">Logout</a>
</div>
<?php include(__DIR__."/../includes/footer.php"); ?>
