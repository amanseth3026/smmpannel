<?php
require_once(__DIR__."/../includes/db.php");
$err = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email=trim($_POST['email']??'');
  $pass=$_POST['password']??'';
  $stmt=$conn->prepare("SELECT id,password FROM admins WHERE email=? LIMIT 1");
  $stmt->bind_param("s",$email); $stmt->execute();
  $res=$stmt->get_result();
  if($row=$res->fetch_assoc()){
    if(password_verify($pass,$row['password'])){
      $_SESSION['admin_id']=$row['id']; $_SESSION['admin_email']=$email;
      header("Location:/admin/dashboard.php"); exit;
    }
  }
  $err="Invalid admin credentials.";
}
include(__DIR__."/../includes/header.php");
?>
<div class="row justify-content-center">
  <div class="col-md-5">
    <div class="card p-4">
      <h3 class="mb-3">Admin Login</h3>
      <?php if($err): ?><div class="alert alert-danger py-2"><?= htmlspecialchars($err) ?></div><?php endif; ?>
      <form method="post">
        <div class="mb-3"><label class="form-label">Email</label><input class="form-control" type="email" name="email" required></div>
        <div class="mb-3"><label class="form-label">Password</label><input class="form-control" type="password" name="password" required></div>
        <button class="btn btn-primary w-100">Login</button>
      </form>
      <small class="muted d-block mt-2">Default admin create: <code>/admin/seed_admin.php</code></small>
    </div>
  </div>
</div>
<?php include(__DIR__."/../includes/footer.php"); ?>
