<?php
require_once(__DIR__."/../includes/db.php");
require_once(__DIR__."/../includes/admin_auth.php");
if($_SERVER['REQUEST_METHOD']==='POST'){
  $id=intval($_POST['id']??0); $status=$_POST['status']??'pending';
  $stmt=$conn->prepare("UPDATE orders SET status=? WHERE id=?");
  $stmt->bind_param("si",$status,$id); $stmt->execute();
  header("Location:/admin/orders.php"); exit;
}
include(__DIR__."/../includes/header.php");
?>
<h3 class="mb-3">Orders</h3>
<div class="card p-0">
  <div class="table-responsive">
    <table class="table table-striped mb-0 align-middle">
      <thead><tr><th>ID</th><th>User</th><th>Service</th><th>Link</th><th>Qty</th><th>Status</th><th>Created</th><th class="text-end">Action</th></tr></thead>
      <tbody>
        <?php
        $q=$conn->query("SELECT o.id,u.email,s.name service,o.link,o.quantity,o.status,o.created_at FROM orders o JOIN users u ON u.id=o.user_id JOIN services s ON s.id=o.service_id ORDER BY o.id DESC");
        while($r=$q->fetch_assoc()): ?>
        <tr>
          <td>#<?= $r['id'] ?></td>
          <td><?= htmlspecialchars($r['email']) ?></td>
          <td><?= htmlspecialchars($r['service']) ?></td>
          <td><small><?= htmlspecialchars($r['link']) ?></small></td>
          <td><?= $r['quantity'] ?></td>
          <td><?= htmlspecialchars($r['status']) ?></td>
          <td><?= $r['created_at'] ?></td>
          <td class="text-end">
            <form method="post" class="d-inline-flex gap-2">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <select class="form-select form-select-sm" name="status">
                <option <?= $r['status']==='pending'?'selected':'' ?>>pending</option>
                <option <?= $r['status']==='processing'?'selected':'' ?>>processing</option>
                <option <?= $r['status']==='completed'?'selected':'' ?>>completed</option>
                <option <?= $r['status']==='canceled'?'selected':'' ?>>canceled</option>
              </select>
              <button class="btn btn-sm btn-primary">Update</button>
            </form>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include(__DIR__."/../includes/footer.php"); ?>
