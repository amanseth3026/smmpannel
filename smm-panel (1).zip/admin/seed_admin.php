<?php
require_once(__DIR__."/../includes/db.php");
$email="admin@example.com"; $pass="admin123";
$hash=password_hash($pass,PASSWORD_DEFAULT);
$stmt=$conn->prepare("INSERT INTO admins(email,password) VALUES(?,?)");
$stmt->bind_param("ss",$email,$hash);
try{ $stmt->execute(); echo "Admin created: $email / $pass"; }
catch(Exception $e){ echo "Error: ".$e->getMessage(); }
