<?php
require_once(__DIR__."/../includes/db.php");
require_once(__DIR__."/../includes/admin_auth.php");

$err="";
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name=trim($_POST['name']??''); $cat=trim($_POST['category']??'');
  $rate=floatval($_POST['rate_per_1k']??0); $min=intval($_POST['min_qty']??0);
  $max=intval($_POST['max_qty']??0); $desc=trim($_POST['description']??'');
  $active=isset($_POST['active'])?1:0;
  if($name && $rate){
    $stmt=$conn->prepare("INSERT INTO services(name,category,rate_per_1k,min_qty,max_qty,description,active) VALUES(?,?,?,?,?,?,?)");
    $stmt->bind_param("ssdiisi",$name,$cat,$rate,$min,$max,$desc,$active);
    $stmt->execute(); header("Location:/admin/services.php"); exit;
  } else { $err="Name and rate are required."; }
}
if(isset($_GET['toggle'])){ $id=intval($_GET['toggle']); $conn->query("UPDATE services SET active=1-active WHERE id=$id"); header("Location:/admin/services.php"); exit; }
include(__DIR__."/../includes/header.php");
?>
<h3 class="mb-3">Services</h3>
<div class="row g-3">
  <div class="col-md-5">
    <div class="card p-3">
      <h5 class="mb-2">Add Service</h5>
      <?php if($err): ?><div class="alert alert-danger py-2"><?= htmlspecialchars($err) ?></div><?php endif; ?>
      <form method="post">
        <div class="mb-2"><label class="form-label">Name</label><input class="form-control" name="name" required></div>
        <div class="mb-2"><label class="form-label">Category</label><input class="form-control" name="category"></div>
        <div class="mb-2"><label class="form-label">Rate (₹ per 1k)</label><input type="number" step="0.01" class="form-control" name="rate_per_1k" required></div>
        <div class="mb-2"><label class="form-label">Min Qty</label><input type="number" class="form-control" name="min_qty" value="10"></div>
        <div class="mb-2"><label class="form-label">Max Qty</label><input type="number" class="form-control" name="max_qty" value="10000"></div>
        <div class="mb-2"><label class="form-label">Description</label><textarea class="form-control" name="description" rows="3"></textarea></div>
        <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="active" id="active" checked><label class="form-check-label" for="active">Active</label></div>
        <button class="btn btn-primary w-100">Add Service</button>
      </form>
    </div>
  </div>
  <div class="col-md-7">
    <div class="card p-0">
      <div class="table-responsive">
        <table class="table table-striped mb-0">
          <thead><tr><th>ID</th><th>Name</th><th>Rate/1k</th><th>Active</th><th></th></tr></thead>
          <tbody>
            <?php $q=$conn->query("SELECT id,name,rate_per_1k,active FROM services ORDER BY id DESC");
            while($s=$q->fetch_assoc()): ?>
            <tr>
              <td>#<?= $s['id'] ?></td>
              <td><?= htmlspecialchars($s['name']) ?></td>
              <td>₹<?= $s['rate_per_1k'] ?></td>
              <td><?= $s['active'] ? 'Yes' : 'No' ?></td>
              <td class="text-end"><a class="btn btn-sm btn-outline-light" href="/admin/services.php?toggle=<?= $s['id'] ?>">Toggle</a></td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include(__DIR__."/../includes/footer.php"); ?>
