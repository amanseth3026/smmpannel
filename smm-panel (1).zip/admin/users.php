<?php
require_once(__DIR__."/../includes/db.php");
require_once(__DIR__."/../includes/admin_auth.php");
include(__DIR__."/../includes/header.php");

// Delete user
if (isset($_GET['delete'])) {
  $id = intval($_GET['delete']);
  $conn->query("DELETE FROM users WHERE id=$id");
  header("Location: /admin/users.php"); exit;
}

// Update balance
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['balance_update'])) {
  $id = intval($_POST['id'] ?? 0);
  $balance = floatval($_POST['balance'] ?? 0);
  $stmt = $conn->prepare("UPDATE users SET balance=? WHERE id=?");
  $stmt->bind_param("di", $balance, $id);
  $stmt->execute();
  header("Location: /admin/users.php"); exit;
}
?>
<h3 class="mb-3">Users</h3>
<div class="card p-0">
  <div class="table-responsive">
    <table class="table table-striped mb-0 align-middle">
      <thead><tr><th>ID</th><th>Name</th><th>Email</th><th style="min-width:220px;">Balance (₹)</th><th>Joined</th><th class="text-end">Actions</th></tr></thead>
      <tbody>
        <?php
          $q=$conn->query("SELECT id,name,email,balance,created_at FROM users ORDER BY id DESC");
          while($u=$q->fetch_assoc()): ?>
          <tr>
            <td>#<?= $u['id'] ?></td>
            <td><?= htmlspecialchars($u['name']) ?></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td>
              <form method="post" class="d-flex gap-2 align-items-center">
                <input type="hidden" name="id" value="<?= $u['id'] ?>">
                <input type="number" step="0.01" class="form-control form-control-sm" name="balance" value="<?= $u['balance'] ?>" required>
                <button class="btn btn-sm btn-primary" name="balance_update">Save</button>
              </form>
            </td>
            <td><?= $u['created_at'] ?></td>
            <td class="text-end">
              <a href="/admin/users.php?delete=<?= $u['id'] ?>" data-confirm="Delete this user?" class="btn btn-sm btn-danger">Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include(__DIR__."/../includes/footer.php"); ?>
