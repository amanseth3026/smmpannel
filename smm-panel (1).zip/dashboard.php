<?php
require_once(__DIR__."/includes/db.php");
require_once(__DIR__."/includes/auth.php");
include(__DIR__."/includes/header.php");
$user_id = $_SESSION['user_id'];

$total=$pending=$completed=0;
$res=$conn->query("SELECT status, COUNT(*) c FROM orders WHERE user_id=$user_id GROUP BY status");
while($r=$res->fetch_assoc()){ $total+=intval($r['c']); if($r['status']==='pending')$pending+=intval($r['c']); if($r['status']==='completed')$completed+=intval($r['c']); }
?>
<h2 class="mb-4">Welcome, <?= htmlspecialchars($_SESSION['user_name'] ?? 'User') ?> 👋</h2>
<div class="row g-3">
  <div class="col-md-4"><div class="card p-3"><h5>Total Orders</h5><div class="display-6"><?= $total ?></div></div></div>
  <div class="col-md-4"><div class="card p-3"><h5>Pending</h5><div class="display-6"><?= $pending ?></div></div></div>
  <div class="col-md-4"><div class="card p-3"><h5>Completed</h5><div class="display-6"><?= $completed ?></div></div></div>
</div>
<div class="card p-3 mt-4">
  <h5 class="mb-3">Quick Order</h5>
  <form class="row g-3" method="post" action="/order.php">
    <div class="col-md-4">
      <label class="form-label">Service</label>
      <select class="form-select" name="service_id" required>
        <option value="">Choose...</option>
        <?php $q=$conn->query("SELECT id,name,rate_per_1k FROM services WHERE active=1 ORDER BY name");
        while($s=$q->fetch_assoc()): ?><option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (₹<?= $s['rate_per_1k'] ?>/1k)</option><?php endwhile; ?>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label">Link/Username</label>
      <input class="form-control" name="link" required>
    </div>
    <div class="col-md-2">
      <label class="form-label">Quantity</label>
      <input type="number" class="form-control" name="quantity" min="10" step="10" required>
    </div>
    <div class="col-md-2 d-flex align-items-end">
      <button class="btn btn-primary w-100">Place</button>
    </div>
  </form>
</div>
<?php include(__DIR__."/includes/footer.php"); ?>
