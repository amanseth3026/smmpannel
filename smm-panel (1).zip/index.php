<?php include(__DIR__."/includes/header.php"); ?>
<div class="p-5 rounded-4 hero text-center">
  <h1 class="display-5 fw-bold">Simple SMM Panel</h1>
  <p class="lead">Buy social media services, manage orders, and track delivery.</p>
  <div class="d-flex gap-3 justify-content-center mt-3">
    <a href="/signup.php" class="btn btn-primary btn-lg">Create an account</a>
    <a href="/login.php" class="btn btn-outline-light btn-lg">Login</a>
  </div>
</div>
<?php include(__DIR__."/includes/footer.php"); ?>
