<?php
require_once(__DIR__."/includes/db.php");
$err = isset($_GET['registered']) ? "Registration successful. Please login." : "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? '');
  $pass  = $_POST['password'] ?? '';
  $stmt=$conn->prepare("SELECT id,password,name FROM users WHERE email=? LIMIT 1");
  $stmt->bind_param("s",$email); $stmt->execute();
  $res=$stmt->get_result();
  if($row=$res->fetch_assoc()) {
    if(password_verify($pass,$row['password'])){
      $_SESSION['user_id']=$row['id']; $_SESSION['user_name']=$row['name'];
      header("Location:/dashboard.php"); exit;
    }
  }
  $err="Invalid email or password.";
}
include(__DIR__."/includes/header.php");
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card p-4">
      <h3 class="mb-3">Login</h3>
      <?php if($err): ?><div class="alert alert-info py-2"><?= htmlspecialchars($err) ?></div><?php endif; ?>
      <form method="post">
        <div class="mb-3"><label class="form-label">Email</label><input type="email" class="form-control" name="email" required></div>
        <div class="mb-3"><label class="form-label">Password</label><input type="password" class="form-control" name="password" required></div>
        <button class="btn btn-primary w-100">Login</button>
      </form>
      <small class="muted d-block mt-2">No account? <a href="/signup.php">Create one</a></small>
    </div>
  </div>
</div>
<?php include(__DIR__."/includes/footer.php"); ?>
