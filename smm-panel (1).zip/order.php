<?php
require_once(__DIR__."/includes/db.php");
require_once(__DIR__."/includes/auth.php");
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $service_id=intval($_POST['service_id']??0);
  $link=trim($_POST['link']??'');
  $qty=intval($_POST['quantity']??0);
  if($service_id && $link && $qty){
    $stmt=$conn->prepare("INSERT INTO orders(user_id,service_id,link,quantity,status) VALUES(?,?,?,?, 'pending')");
    $stmt->bind_param("iisi", $_SESSION['user_id'], $service_id, $link, $qty);
    $stmt->execute();
    header("Location:/orders.php?placed=1"); exit;
  }
}
header("Location:/dashboard.php"); exit;
