<?php
require_once(__DIR__."/includes/db.php");
require_once(__DIR__."/includes/auth.php");
include(__DIR__."/includes/header.php");
$placed=isset($_GET['placed']);
?>
<h3 class="mb-3">My Orders</h3>
<?php if($placed): ?><div class="alert alert-success py-2">Order placed successfully.</div><?php endif; ?>
<div class="card p-0">
  <div class="table-responsive">
    <table class="table table-striped mb-0">
      <thead><tr><th>ID</th><th>Service</th><th>Link</th><th>Qty</th><th>Status</th><th>Created</th></tr></thead>
      <tbody>
      <?php
      $uid=$_SESSION['user_id'];
      $q=$conn->query("SELECT o.id,s.name service,o.link,o.quantity,o.status,o.created_at FROM orders o JOIN services s ON s.id=o.service_id WHERE o.user_id=$uid ORDER BY o.id DESC");
      while($r=$q->fetch_assoc()): ?>
        <tr>
          <td>#<?= $r['id'] ?></td>
          <td><?= htmlspecialchars($r['service']) ?></td>
          <td><small><?= htmlspecialchars($r['link']) ?></small></td>
          <td><?= $r['quantity'] ?></td>
          <td><span class="badge bg-<?= $r['status']==='completed'?'success':($r['status']==='canceled'?'danger':'warning') ?>"><?= htmlspecialchars($r['status']) ?></span></td>
          <td><?= $r['created_at'] ?></td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include(__DIR__."/includes/footer.php"); ?>
