<?php
require_once(__DIR__."/includes/db.php");
$err = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $pass = $_POST['password'] ?? '';
  if (!$name || !$email || !$pass) {
    $err = "Please fill all fields.";
  } else {
    $stmt=$conn->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
    $stmt->bind_param("s",$email);
    $stmt->execute(); $stmt->store_result();
    if ($stmt->num_rows>0) { $err="Email already exists."; }
    else {
      $hash = password_hash($pass, PASSWORD_DEFAULT);
      $stmt=$conn->prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)");
      $stmt->bind_param("sss",$name,$email,$hash); $stmt->execute();
      header("Location:/login.php?registered=1"); exit;
    }
  }
}
include(__DIR__."/includes/header.php");
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card p-4">
      <h3 class="mb-3">Create account</h3>
      <?php if($err): ?><div class="alert alert-danger py-2"><?= htmlspecialchars($err) ?></div><?php endif; ?>
      <form method="post">
        <div class="mb-3"><label class="form-label">Full name</label><input class="form-control" name="name" required></div>
        <div class="mb-3"><label class="form-label">Email</label><input type="email" class="form-control" name="email" required></div>
        <div class="mb-3"><label class="form-label">Password</label><input type="password" class="form-control" name="password" minlength="6" required></div>
        <button class="btn btn-primary w-100">Sign up</button>
      </form>
      <small class="muted d-block mt-2">Already have an account? <a href="/login.php">Login</a></small>
    </div>
  </div>
</div>
<?php include(__DIR__."/includes/footer.php"); ?>
